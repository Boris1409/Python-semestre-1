"""Utilizando ciclos se pide construya un programa que permita imprimir en la salida estándar
la siguiente pirámide"""


